# Welcome to the SLURM Bundle
This bundle provisions a minimal slurm deployment consisting of; slurmdbd
slurmctld, slurmd and percona-cluster.

## Usage
Assuming you have `juju` installed, simply run:
```bash
juju deploy slurm
```
